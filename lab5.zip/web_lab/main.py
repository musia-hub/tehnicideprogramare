import argparse
import csv
from datetime import datetime
from webtools import fetch, get_title, security_headers, check_paths, site_report

# EX 44
print("Titlu:", get_title(fetch(url).text))


# EX 45
print("Antete:", security_headers(url))


# EX 48
parser = argparse.ArgumentParser()
parser.add_argument("url")
url = parser.parse_args().url


# EX 49
with open("report.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["path", "status", "checked_at"])

    for p, s in check_paths(url):
        w.writerow([p, s, datetime.now().isoformat()])


# EX 50
site_report(url)